MANUAL :
1. Unzip all files from archive
2. Go to folder Version_Unlimited
3. Run file: Full_Version.exe